var plasma = getApiVersion(1);

var layout = {
    "desktops": [
        {
            "applets": [
                {
                    "config": {
                        "/ConfigDialog": {
                            "DialogHeight": "420",
                            "DialogWidth": "560"
                        },
                        "/General": {
                            "showSecondHand": "true"
                        }
                    },
                    "geometry.height": 20,
                    "geometry.width": 24,
                    "geometry.x": 109,
                    "geometry.y": 0,
                    "plugin": "org.kde.plasma.analogclock",
                    "title": "Analogue Clock"
                },
                {
                    "config": {
                        "/General": {
                            "url": "https://m.facebook.com/"
                        }
                    },
                    "geometry.height": 35,
                    "geometry.width": 27,
                    "geometry.x": 109,
                    "geometry.y": 20,
                    "plugin": "org.kde.plasma.webbrowser",
                    "title": "Web browser"
                },
                {
                    "config": {
                        "/": {
                            "arrowsOnHover": "true",
                            "checkNewComicStripsIntervall": "30",
                            "comic": "garfield",
                            "lastStripVisited_garfield": "true",
                            "lastStrip_garfield": "2018-02-08",
                            "maxComicLimit": "20",
                            "maxStripNum_garfield": "0",
                            "middleClick": "true",
                            "savingDir": "/home/paul/Pictures",
                            "scaleToContent_garfield": "false",
                            "showComicAuthor": "false",
                            "showComicIdentifier": "false",
                            "showComicTitle": "false",
                            "showComicUrl": "false",
                            "showErrorPicture": "true",
                            "storedPosition_garfield": "",
                            "tabIdentifier": "garfield"
                        },
                        "/ConfigDialog": {
                            "DialogHeight": "420",
                            "DialogWidth": "560"
                        }
                    },
                    "geometry.height": 16,
                    "geometry.width": 51,
                    "geometry.x": 85,
                    "geometry.y": 56,
                    "plugin": "org.kde.plasma.comic",
                    "title": "Comic Strip"
                }
            ],
            "config": {
                "/": {
                    "formfactor": "0",
                    "immutability": "1",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.image"
                },
                "/ConfigDialog": {
                    "DialogHeight": "480",
                    "DialogWidth": "640"
                },
                "/General": {
                    "ToolBoxButtonState": "top",
                    "ToolBoxButtonX": "1789",
                    "arrangement": "1",
                    "iconSize": "3",
                    "positions": "1,11,desktop:/fritzing.desktop,0,3,desktop:/mozilla-thunderbird.desktop,0,2,desktop:/firefox.desktop,0,1,desktop:/org.kde.dolphin.desktop,0,0,desktop:/Splash.qml,0,5,desktop:/login-scan-splash-cg.tar.gz,0,4",
                    "sortMode": "-1"
                },
                "/Wallpaper/org.kde.image/General": {
                    "FillMode": "2",
                    "Image": "file:///usr/share/wallpapers/EveningGlow/contents/images/1920x1080.jpg",
                    "height": "900",
                    "width": "1600"
                }
            },
            "wallpaperPlugin": "org.kde.image"
        }
    ],
    "panels": [
        {
            "alignment": "left",
            "applets": [
                {
                    "config": {
                        "/": {
                            "immutability": "1"
                        },
                        "/Configuration": {
                            "immutability": "1"
                        },
                        "/Configuration/Configuration/ConfigDialog": {
                            "DialogHeight": "480",
                            "DialogWidth": "640"
                        },
                        "/Configuration/Configuration/General": {
                            "favoriteApps": "systemsettings.desktop,org.kde.dolphin.desktop,org.kde.kate.desktop,org.kde.konsole.desktop",
                            "favoriteSystemActions": "",
                            "favoritesPortedToKAstats": "true",
                            "limitDepth": "true",
                            "showRecentDocs": "false"
                        },
                        "/Configuration/General": {
                            "favoriteApps": "systemsettings.desktop\\,org.kde.dolphin.desktop\\,org.kde.kate.desktop\\,org.kde.konsole.desktop",
                            "favoriteSystemActions": "",
                            "favoritesPortedToKAstats": "true",
                            "limitDepth": "true",
                            "showRecentDocs": "false"
                        },
                        "/Configuration/Shortcuts": {
                            "global": "Alt+F1"
                        },
                        "/Shortcuts": {
                            "global": "Alt+F1"
                        }
                    },
                    "plugin": "org.kde.plasma.kicker"
                },
                {
                    "config": {
                        "/": {
                            "immutability": "1"
                        },
                        "/Configuration": {
                            "localPath": "/home/paul/.local/share/plasma_icons/mozilla-thunderbird.desktop",
                            "url": "file:///usr/share/applications/mozilla-thunderbird.desktop"
                        }
                    },
                    "plugin": "org.kde.plasma.icon"
                },
                {
                    "config": {
                        "/": {
                            "immutability": "1"
                        },
                        "/Configuration": {
                            "localPath": "/home/paul/.local/share/plasma_icons/firefox.desktop",
                            "url": "file:///usr/share/applications/firefox.desktop"
                        }
                    },
                    "plugin": "org.kde.plasma.icon"
                },
                {
                    "config": {
                        "/": {
                            "immutability": "1"
                        },
                        "/Configuration": {
                            "localPath": "/home/paul/.local/share/plasma_icons/org.kde.dolphin.desktop",
                            "url": "file:///usr/share/applications/org.kde.dolphin.desktop"
                        }
                    },
                    "plugin": "org.kde.plasma.icon"
                },
                {
                    "config": {
                        "/": {
                            "immutability": "1"
                        },
                        "/Configuration": {
                            "localPath": "/home/paul/.local/share/plasma_icons/pclinuxos-drakconf.desktop",
                            "url": "file:///usr/share/applications/pclinuxos-drakconf.desktop"
                        }
                    },
                    "plugin": "org.kde.plasma.icon"
                },
                {
                    "config": {
                        "/": {
                            "immutability": "1"
                        },
                        "/Configuration": {
                            "localPath": "/home/paul/.local/share/plasma_icons/systemsettings.desktop",
                            "url": "file:///usr/share/applications/systemsettings.desktop"
                        }
                    },
                    "plugin": "org.kde.plasma.icon"
                },
                {
                    "config": {
                        "/": {
                            "immutability": "1"
                        },
                        "/Configuration": {
                            "localPath": "/home/paul/.local/share/plasma_icons/synaptic-kde.desktop",
                            "url": "file:///usr/share/applications/synaptic-kde.desktop"
                        }
                    },
                    "plugin": "org.kde.plasma.icon"
                },
                {
                    "config": {
                        "/": {
                            "immutability": "1"
                        },
                        "/Configuration": {
                            "immutability": "1"
                        }
                    },
                    "plugin": "org.kde.plasma.pager"
                },
                {
                    "config": {
                        "/": {
                            "immutability": "1"
                        },
                        "/Configuration": {
                            "immutability": "1"
                        },
                        "/Configuration/Configuration/ConfigDialog": {
                            "DialogHeight": "540",
                            "DialogWidth": "720"
                        },
                        "/Configuration/Configuration/General": {
                            "showToolTips": "false"
                        },
                        "/Configuration/General": {
                            "showToolTips": "false"
                        }
                    },
                    "plugin": "org.kde.plasma.taskmanager"
                },
                {
                    "config": {
                        "/": {
                            "immutability": "1"
                        },
                        "/Configuration": {
                            "immutability": "1"
                        }
                    },
                    "plugin": "org.kde.plasma.systemtray"
                },
                {
                    "config": {
                        "/": {
                            "immutability": "1"
                        },
                        "/Configuration": {
                            "immutability": "1"
                        }
                    },
                    "plugin": "org.kde.plasma.volumewin7mixer"
                },
                {
                    "config": {
                        "/": {
                            "immutability": "1"
                        },
                        "/Configuration": {
                            "immutability": "1"
                        },
                        "/Configuration/Configuration/ConfigDialog": {
                            "DialogHeight": "729",
                            "DialogWidth": "1089"
                        },
                        "/Configuration/Configuration/General": {
                            "clock_24h": "true",
                            "clock_line_1_bold": "true",
                            "clock_line_2": "true",
                            "clock_line_2_bold": "true",
                            "clock_timeformat_2": "ddd M/d/yy"
                        },
                        "/Configuration/General": {
                            "clock_24h": "true",
                            "clock_line_1_bold": "true",
                            "clock_line_2": "true",
                            "clock_line_2_bold": "true",
                            "clock_timeformat_2": "ddd M/d/yy"
                        }
                    },
                    "plugin": "org.kde.plasma.eventcalendar"
                }
            ],
            "config": {
                "/": {
                    "formfactor": "2",
                    "immutability": "1",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.image"
                },
                "/ConfigDialog": {
                    "DialogHeight": "80",
                    "DialogWidth": "1920"
                }
            },
            "height": 2.5714285714285716,
            "hiding": "autohide",
            "location": "bottom",
            "maximumLength": 137.14285714285714,
            "minimumLength": 137.14285714285714,
            "offset": 0
        }
    ],
    "serializationFormatVersion": "1"
}
;

plasma.loadSerializedLayout(layout);
